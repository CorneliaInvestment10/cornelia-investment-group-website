// keeps config accessible from pages folder
