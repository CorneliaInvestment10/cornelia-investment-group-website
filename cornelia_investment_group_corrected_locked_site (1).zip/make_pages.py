import os
pages={
'index.html':('../assets/homepage-locked.jpeg','home'),
'pages/solutions.html':('../assets/solutions-locked.jpeg','solutions'),
'pages/industries.html':('../assets/industries-locked.jpeg','industries'),
'pages/about.html':('../assets/about-locked.jpeg','about'),
'pages/explore-options.html':('../assets/explore-options-locked.jpeg','explore'),
'pages/construction.html':('../assets/construction-locked.jpeg','construction'),
'pages/healthcare.html':('../assets/healthcare-locked.jpeg','healthcare'),
'pages/manufacturing.html':('../assets/manufacturing-locked.jpeg','manufacturing'),
}
# paths from root vs pages
for fn,(img,key) in pages.items():
    in_pages=fn.startswith('pages/')
    css='../assets/css/site.css' if in_pages else 'assets/css/site.css'
    js='../assets/js/leads.js' if in_pages else 'assets/js/leads.js'
    config='../config.js' if in_pages else 'config.js'
    home='../index.html' if in_pages else 'index.html'
    sol='solutions.html' if in_pages else 'pages/solutions.html'
    ind='industries.html' if in_pages else 'pages/industries.html'
    about='about.html' if in_pages else 'pages/about.html'
    explore='explore-options.html' if in_pages else 'pages/explore-options.html'
    construction='construction.html' if in_pages else 'pages/construction.html'
    manufacturing='manufacturing.html' if in_pages else 'pages/manufacturing.html'
    healthcare='healthcare.html' if in_pages else 'pages/healthcare.html'
    hotspots=f'''
<a class="hotspot" href="{home}" style="left:0%;top:0%;width:28%;height:5%;" aria-label="Home"></a>
<a class="hotspot" href="{sol}" style="left:36%;top:0%;width:11%;height:5%;" aria-label="Solutions"></a>
<a class="hotspot" href="{ind}" style="left:49%;top:0%;width:12%;height:5%;" aria-label="Industries"></a>
<a class="hotspot" href="{about}" style="left:63%;top:0%;width:12%;height:5%;" aria-label="About Us"></a>
<a class="hotspot" href="{explore}" style="left:78%;top:1%;width:18%;height:3.5%;" aria-label="Explore Options"></a>
'''
    # page-specific lower buttons
    if key=='home':
        hotspots += f'''
<a class="hotspot" href="{construction}" style="left:3%;top:42%;width:11%;height:4%;" aria-label="Construction"></a>
<a class="hotspot" href="{manufacturing}" style="left:15%;top:42%;width:13%;height:4%;" aria-label="Manufacturing"></a>
<a class="hotspot" href="{healthcare}" style="left:29%;top:42%;width:14%;height:4%;" aria-label="Healthcare"></a>
<a class="hotspot" href="{construction}" style="left:10%;top:91%;width:14%;height:3%;" aria-label="Learn More Construction"></a>
<a class="hotspot" href="{manufacturing}" style="left:43%;top:91%;width:14%;height:3%;" aria-label="Learn More Manufacturing"></a>
<a class="hotspot" href="{healthcare}" style="left:76%;top:91%;width:14%;height:3%;" aria-label="Learn More Healthcare"></a>
<form class="lead-form" aria-label="Homepage lead form">
<label class="hidden-label">Full Name<input class="field" name="fullName" style="left:78%;top:18.2%;width:16%;height:2.2%;"></label>
<label class="hidden-label">Business Name<input class="field" name="businessName" style="left:78%;top:21.8%;width:16%;height:2.2%;"></label>
<label class="hidden-label">Annual Revenue<select class="field select" name="annualRevenue" style="left:78%;top:25.5%;width:16%;height:2.2%;"><option></option><option>$1M-$2M</option><option>$2M-$5M</option><option>$5M+</option></select></label>
<label class="hidden-label">Industry<select class="field select" name="industry" style="left:78%;top:29.2%;width:16%;height:2.2%;"><option></option><option>Construction</option><option>Manufacturing</option><option>Healthcare</option></select></label>
<label class="hidden-label">Funding Need<input class="field" name="fundingNeed" style="left:78%;top:33%;width:16%;height:2.2%;"></label>
<label class="hidden-label">Phone<input class="field" name="phone" style="left:78%;top:36.7%;width:16%;height:2.2%;"></label>
<label class="hidden-label">Email<input class="field" name="email" style="left:78%;top:40.4%;width:16%;height:2.2%;"></label>
<label class="hidden-label">Marketing Consent<input class="check" type="checkbox" name="marketingConsent" style="left:67%;top:43.8%;"></label>
<button class="submit" style="left:67%;top:45.5%;width:29%;height:4.2%;" aria-label="Continue to explore options"></button>
</form>
<div class="fallback-form"><form class="lead-form"><h2>Tell Us About Your Business</h2><input name="fullName" placeholder="Full Name"><input name="businessName" placeholder="Business Name"><input name="email" placeholder="Email"><input name="phone" placeholder="Phone"><select name="industry"><option>Industry</option><option>Construction</option><option>Manufacturing</option><option>Healthcare</option></select><select name="annualRevenue"><option>Annual Revenue</option><option>$1M-$2M</option><option>$2M-$5M</option><option>$5M+</option></select><input name="fundingNeed" placeholder="Funding Need"><label><input type="checkbox" name="marketingConsent"> I agree to receive marketing communications.</label><button>Continue to Explore Options</button></form></div>
'''
    if key=='explore':
        hotspots += f'''
<form class="lead-form" aria-label="Explore options lead form">
<input class="field" name="fullName" style="left:46%;top:38%;width:23%;height:2.5%;"><input class="field" name="title" style="left:71%;top:38%;width:23%;height:2.5%;"><input class="field" name="businessName" style="left:46%;top:43.5%;width:23%;height:2.5%;"><select class="field select" name="industry" style="left:71%;top:43.5%;width:23%;height:2.5%;"><option></option><option>Construction</option><option>Manufacturing</option><option>Healthcare</option></select><input class="field" name="email" style="left:46%;top:49%;width:23%;height:2.5%;"><input class="field" name="phone" style="left:71%;top:49%;width:23%;height:2.5%;"><select class="field select" name="annualRevenue" style="left:46%;top:55%;width:48%;height:2.5%;"><option></option><option>$1M-$2M</option><option>$2M-$5M</option><option>$5M+</option></select><select class="field select" name="timeInBusiness" style="left:46%;top:61%;width:23%;height:2.5%;"><option></option><option>1-2 Years</option><option>2-5 Years</option><option>5+ Years</option></select><select class="field select" name="creditScore" style="left:71%;top:61%;width:23%;height:2.5%;"><option></option><option>620-679</option><option>680-719</option><option>720+</option></select><textarea class="field" name="fundingNeed" style="left:46%;top:66.8%;width:48%;height:6.2%;"></textarea><input class="check" type="checkbox" name="marketingConsent" style="left:48%;top:75.2%;"><button class="submit" style="left:46%;top:78.3%;width:48%;height:4%;"></button>
</form>
<div class="fallback-form"><form class="lead-form"><h2>Tell Us About Your Business</h2><input name="fullName" placeholder="Full Name"><input name="title" placeholder="Title"><input name="businessName" placeholder="Business Name"><input name="email" placeholder="Email"><input name="phone" placeholder="Phone"><select name="industry"><option>Industry</option><option>Construction</option><option>Manufacturing</option><option>Healthcare</option></select><select name="annualRevenue"><option>Annual Revenue</option><option>$1M-$2M</option><option>$2M-$5M</option><option>$5M+</option></select><select name="timeInBusiness"><option>Time in Business</option><option>1-2 Years</option><option>2-5 Years</option><option>5+ Years</option></select><select name="creditScore"><option>Credit Score</option><option>620-679</option><option>680-719</option><option>720+</option></select><textarea name="fundingNeed" placeholder="Financing Need / Purpose"></textarea><label><input type="checkbox" name="marketingConsent"> I agree to receive marketing communications.</label><button>Submit & Explore Options</button></form></div>
'''
    if key=='industries':
        hotspots += f'<a class="hotspot" href="{construction}" style="left:2%;top:43%;width:24%;height:47%;"></a><a class="hotspot" href="{manufacturing}" style="left:27%;top:43%;width:24%;height:47%;"></a><a class="hotspot" href="{healthcare}" style="left:52%;top:43%;width:24%;height:47%;"></a>'
    if key in ['solutions','construction','manufacturing','healthcare','about']:
        hotspots += f'<a class="hotspot" href="{explore}" style="left:5%;top:35%;width:25%;height:5%;"></a><a class="hotspot" href="{explore}" style="left:68%;top:83%;width:26%;height:5%;"></a>'
    html=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cornelia Investment Group</title><link rel="stylesheet" href="{css}"><script src="{config}"></script><script src="{js}" defer></script></head><body><main class="page"><img class="locked" src="{img}" alt="Cornelia Investment Group locked website preview">{hotspots}</main></body></html>'''
    open(fn,'w').write(html)
