// Paste your NBC partner tracking link below when ready.
// Example: const NBC_REDIRECT_URL = "https://www.nationalbusinesscapital.com/apply-now/?ref=YOURCODE";
const NBC_REDIRECT_URL = "PASTE-YOUR-NBC-LINK-HERE";
const REDIRECT_DELAY_MS = 900;
