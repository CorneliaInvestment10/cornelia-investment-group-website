Cornelia Investment Group Website Package

UPLOAD INSTRUCTIONS:
1. Extract this ZIP on your computer.
2. Upload everything inside the extracted folder to GitHub.
3. Do not upload only the ZIP file if GitHub is asking for website files.
4. Keep these folders together: assets, pages, css/js files, index.html, config.js.

NBC LINK:
Open config.js and replace PASTE-YOUR-NBC-LINK-HERE with your NBC tracking link.

LEADS:
The form saves leads locally for testing and allows CSV export at pages/leads.html.
For real live visitor lead capture, connect the form to Google Sheets, Airtable, HubSpot, Zoho, Mailchimp, or a database because browser local storage only saves leads on the current device.

LOCKED PREVIEW:
The page images in assets are the locked screenshots provided. The website displays those images with connected click areas and form overlays.
