# Cornelia Investment Group Website

Static landing page for business financing access.

Files:
- `index.html`
- `thank-you.html`

This site is designed for Vercel static deployment.
